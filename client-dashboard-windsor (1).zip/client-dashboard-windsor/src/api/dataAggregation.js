import { fetchRevenueData, calculateTotals } from './googleSheets';

// Aggregate all client data from multiple sources
export const aggregateClientData = async (clientName) => {
  try {
    const revenueData = await fetchRevenueData();

    const clientRevenue = revenueData.clients.find((c) => c.name === clientName);

    return {
      revenue: clientRevenue || {},
      actionItems: [],
      communication: {},
      lastMeeting: null,
      months: revenueData.months,
    };
  } catch (error) {
    console.error('Error aggregating client data:', error);
    return {
      revenue: {},
      actionItems: [],
      communication: {},
      lastMeeting: null,
      months: [],
    };
  }
};

// Aggregate dashboard-wide metrics
export const aggregateDashboardMetrics = async (clients) => {
  try {
    const { clients: revenueClients } = await fetchRevenueData();
    const totals = calculateTotals(revenueClients);

    const clientMetrics = clients.map((clientName) => {
      const clientData = revenueClients.find((c) => c.name === clientName);
      return {
        name: clientName,
        revenue: clientData || {},
        pendingActions: 0,
        lastUpdate: new Date(),
      };
    });

    return {
      totals,
      clients: clientMetrics,
      timestamp: new Date(),
    };
  } catch (error) {
    console.error('Error aggregating dashboard metrics:', error);
    return { totals: {}, clients: [], timestamp: new Date() };
  }
};

// Calculate trends
export const calculateClientTrends = (monthlyData, months) => {
  const trends = {};

  months.forEach((month) => {
    const monthValue = monthlyData[month]
      ? Object.values(monthlyData[month]).reduce((sum, val) => sum + val, 0)
      : 0;
    trends[month] = monthValue;
  });

  // Calculate month-over-month growth
  const monthArray = Object.entries(trends);
  const growth = {};

  for (let i = 1; i < monthArray.length; i++) {
    const [month, value] = monthArray[i];
    const [, prevValue] = monthArray[i - 1];

    if (prevValue > 0) {
      growth[month] = ((value - prevValue) / prevValue) * 100;
    }
  }

  return { trends, growth };
};

// CSat tracking (input/stored separately)
export const formatCSatData = (clientScores) => {
  return clientScores.map((score) => ({
    client: score.clientName,
    month: score.month,
    score: score.score,
    feedback: score.feedback || '',
  }));
};
