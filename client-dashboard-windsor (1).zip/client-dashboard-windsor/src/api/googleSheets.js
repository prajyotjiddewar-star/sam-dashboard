// Updated googleSheets.js - calls Netlify Function which uses Windsor.ai
// This keeps the same interface for the rest of your app

export const fetchRevenueData = async () => {
  try {
    const response = await fetch('/.netlify/functions/fetchData');

    if (!response.ok) {
      throw new Error(`Server error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();

    if (data.error) {
      throw new Error(data.error);
    }

    return data;
  } catch (error) {
    console.error('Error fetching revenue data via Windsor:', error);
    throw error;
  }
};

export const fetchClientSummary = async (clientName) => {
  try {
    const data = await fetchRevenueData();
    return data.clients.find((c) => c.name === clientName);
  } catch (error) {
    console.error('Error fetching client summary:', error);
    throw error;
  }
};

export const calculateTotals = (clients) => {
  const totals = {
    totalRevenue: 0,
    totalProjection: 0,
    activeClients: clients.length,
  };

  clients.forEach((client) => {
    totals.totalRevenue += client.actual;
    totals.totalProjection += client.projection;
  });

  return totals;
};
