import React from 'react';
import '../styles/Overview.css';

const Overview = ({ totals, lastUpdate }) => {
  const avgRevenuePerClient = totals.activeClients > 0
    ? (totals.totalRevenue / totals.activeClients).toFixed(0)
    : 0;

  const achievementRate = totals.totalProjection > 0
    ? ((totals.totalRevenue / totals.totalProjection) * 100).toFixed(1)
    : 0;

  return (
    <div className="overview-section">
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-label">Total Actual Revenue (YTD)</div>
          <div className="kpi-value">₹{(totals.totalRevenue / 100000).toFixed(1)}L</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Total Projection (FY)</div>
          <div className="kpi-value">₹{(totals.totalProjection / 100000).toFixed(1)}L</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Achievement Rate</div>
          <div className="kpi-value">{achievementRate}%</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Active Clients</div>
          <div className="kpi-value">{totals.activeClients}</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Avg Revenue/Client</div>
          <div className="kpi-value">₹{(avgRevenuePerClient / 100000).toFixed(1)}L</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Last Update</div>
          <div className="kpi-value">{lastUpdate.toLocaleTimeString('en-IN')}</div>
        </div>
      </div>
    </div>
  );
};

export default Overview;
