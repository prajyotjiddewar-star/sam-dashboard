import React, { useState, useEffect } from 'react';
import '../styles/CSatForm.css';

const CSatForm = ({ clients, months }) => {
  const [formData, setFormData] = useState({
    clientName: clients[0] || '',
    month: months[months.length - 1] || '',
    score: 5,
    feedback: '',
  });

  const [submissions, setSubmissions] = useState([]);

  // Load submissions from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('csatSubmissions');
    if (stored) {
      setSubmissions(JSON.parse(stored));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'score' ? parseInt(value) : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newSubmission = {
      ...formData,
      timestamp: new Date().toISOString(),
    };
    const updated = [...submissions, newSubmission];
    setSubmissions(updated);
    localStorage.setItem('csatSubmissions', JSON.stringify(updated));

    // Reset form
    setFormData({
      clientName: clients[0] || '',
      month: months[months.length - 1] || '',
      score: 5,
      feedback: '',
    });
    alert('CSat score submitted successfully!');
  };

  const avgScore = submissions.length > 0
    ? (submissions.reduce((sum, s) => sum + s.score, 0) / submissions.length).toFixed(1)
    : 0;

  return (
    <div className="csat-section">
      <h2>Customer Satisfaction (CSat) Tracking</h2>

      <div className="csat-grid">
        <div className="csat-form-container">
          <form onSubmit={handleSubmit} className="csat-form">
            <div className="form-group">
              <label>Client</label>
              <select
                name="clientName"
                value={formData.clientName}
                onChange={handleChange}
                required
              >
                {clients.map((client) => (
                  <option key={client} value={client}>{client}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Month</label>
              <select
                name="month"
                value={formData.month}
                onChange={handleChange}
                required
              >
                {months.map((month) => (
                  <option key={month} value={month}>{month}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>CSat Score (0-10)</label>
              <input
                type="range"
                name="score"
                min="0"
                max="10"
                value={formData.score}
                onChange={handleChange}
              />
              <div className="score-display">{formData.score} / 10</div>
            </div>

            <div className="form-group">
              <label>Feedback</label>
              <textarea
                name="feedback"
                value={formData.feedback}
                onChange={handleChange}
                placeholder="Enter any feedback or notes..."
                rows="4"
              />
            </div>

            <button type="submit" className="submit-btn">Submit CSat Score</button>
          </form>
        </div>

        <div className="csat-stats">
          <div className="stat-card">
            <div className="stat-label">Average CSat Score</div>
            <div className="stat-value">{avgScore}/10</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Total Submissions</div>
            <div className="stat-value">{submissions.length}</div>
          </div>
        </div>
      </div>

      {submissions.length > 0 && (
        <div className="submissions-history">
          <h3>Recent Submissions</h3>
          <table className="submissions-table">
            <thead>
              <tr>
                <th>Client</th>
                <th>Month</th>
                <th>Score</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {submissions.slice(-10).reverse().map((submission, idx) => (
                <tr key={idx}>
                  <td>{submission.clientName}</td>
                  <td>{submission.month}</td>
                  <td>{submission.score}/10</td>
                  <td>{new Date(submission.timestamp).toLocaleDateString('en-IN')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default CSatForm;
