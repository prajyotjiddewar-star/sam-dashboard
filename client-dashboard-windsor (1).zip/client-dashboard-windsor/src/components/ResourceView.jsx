import React, { useState } from 'react';
import '../styles/ResourceView.css';

const ResourceView = ({ clients }) => {
  const services = ['Strategy', 'Creative', 'Media', 'Reporting', 'Account Mgmt'];

  const [resources, setResources] = useState(() => {
    const stored = localStorage.getItem('resourceAllocation');
    if (stored) return JSON.parse(stored);

    const initial = {};
    clients.forEach((client) => {
      initial[client] = {};
      services.forEach((service) => {
        initial[client][service] = 0;
      });
    });
    return initial;
  });

  const [editMode, setEditMode] = useState(false);

  const handleChange = (client, service, value) => {
    setResources((prev) => ({
      ...prev,
      [client]: {
        ...prev[client],
        [service]: parseFloat(value) || 0,
      },
    }));
  };

  const handleSave = () => {
    localStorage.setItem('resourceAllocation', JSON.stringify(resources));
    setEditMode(false);
    alert('Resource allocation saved!');
  };

  const getTotalFTE = () => {
    return Object.values(resources)
      .reduce((sum, client) => sum + Object.values(client).reduce((s, v) => s + v, 0), 0)
      .toFixed(1);
  };

  const getClientTotal = (client) => {
    return Object.values(resources[client] || {})
      .reduce((sum, val) => sum + val, 0)
      .toFixed(1);
  };

  return (
    <div className="resource-section">
      <div className="resource-header">
        <h2>Resource Allocation</h2>
        <button
          className={`edit-btn ${editMode ? 'active' : ''}`}
          onClick={() => setEditMode(!editMode)}
        >
          {editMode ? 'Cancel' : 'Edit'}
        </button>
        {editMode && (
          <button className="save-btn" onClick={handleSave}>Save</button>
        )}
      </div>

      <div className="resource-table-wrapper">
        <table className="resource-table">
          <thead>
            <tr>
              <th>Client</th>
              {services.map((service) => (
                <th key={service}>{service}</th>
              ))}
              <th>Total FTE</th>
            </tr>
          </thead>
          <tbody>
            {clients.map((client) => (
              <tr key={client}>
                <td className="client-col">{client}</td>
                {services.map((service) => (
                  <td key={`${client}-${service}`} className="resource-cell">
                    {editMode ? (
                      <input
                        type="number"
                        min="0"
                        step="0.5"
                        value={resources[client]?.[service] || 0}
                        onChange={(e) => handleChange(client, service, e.target.value)}
                      />
                    ) : (
                      <span>{resources[client]?.[service] || 0}</span>
                    )}
                  </td>
                ))}
                <td className="total-cell">{getClientTotal(client)} FTE</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <th>Total</th>
              {services.map((service) => {
                const total = clients
                  .reduce((sum, client) => sum + (resources[client]?.[service] || 0), 0)
                  .toFixed(1);
                return <th key={`total-${service}`}>{total}</th>;
              })}
              <th>{getTotalFTE()} FTE</th>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="resource-info">
        <p>FTE = Full-Time Equivalent (1.0 = full-time, 0.5 = half-time, etc.)</p>
        <p>Total Organization FTE: <strong>{getTotalFTE()}</strong></p>
      </div>
    </div>
  );
};

export default ResourceView;
