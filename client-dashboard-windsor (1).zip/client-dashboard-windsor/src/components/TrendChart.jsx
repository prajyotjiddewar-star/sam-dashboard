import React, { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import '../styles/TrendChart.css';

const TrendChart = ({ clients, months }) => {
  const [chartType, setChartType] = useState('line');
  const [selectedClients, setSelectedClients] = useState(
    clients.slice(0, 3).map((c) => c.name)
  );

  // Prepare chart data
  const chartData = months.map((month) => {
    const dataPoint = { month };
    selectedClients.forEach((clientName) => {
      const client = clients.find((c) => c.name === clientName);
      if (client && client.monthlyData[month]) {
        const monthTotal = Object.values(client.monthlyData[month]).reduce((sum, val) => sum + val, 0);
        dataPoint[clientName] = monthTotal / 100000;
      }
    });
    return dataPoint;
  });

  const colors = ['#667eea', '#764ba2', '#f093fb', '#4facfe', '#00f2fe'];

  const toggleClient = (clientName) => {
    setSelectedClients((prev) =>
      prev.includes(clientName)
        ? prev.filter((c) => c !== clientName)
        : [...prev, clientName]
    );
  };

  return (
    <div className="trend-chart-section">
      <h2>Revenue Trends</h2>

      <div className="chart-controls">
        <div className="chart-type-selector">
          <button
            className={chartType === 'line' ? 'active' : ''}
            onClick={() => setChartType('line')}
          >
            Line Chart
          </button>
          <button
            className={chartType === 'bar' ? 'active' : ''}
            onClick={() => setChartType('bar')}
          >
            Bar Chart
          </button>
        </div>
      </div>

      <div className="chart-container">
        <ResponsiveContainer width="100%" height={400}>
          {chartType === 'line' ? (
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              {selectedClients.map((clientName, idx) => (
                <Line
                  key={clientName}
                  type="monotone"
                  dataKey={clientName}
                  stroke={colors[idx % colors.length]}
                  connectNulls
                />
              ))}
            </LineChart>
          ) : (
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              {selectedClients.map((clientName, idx) => (
                <Bar
                  key={clientName}
                  dataKey={clientName}
                  fill={colors[idx % colors.length]}
                />
              ))}
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>

      <div className="client-filter">
        <h4>Select Clients to Display:</h4>
        <div className="filter-buttons">
          {clients.map((client) => (
            <button
              key={client.name}
              className={`filter-btn ${selectedClients.includes(client.name) ? 'active' : ''}`}
              onClick={() => toggleClient(client.name)}
            >
              {client.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrendChart;
