import React, { useState } from 'react';
import '../styles/ClientTable.css';

const ClientTable = ({ clients, months, onSelectClient, selectedClient }) => {
  const [expandedClient, setExpandedClient] = useState(null);

  const toggleExpand = (clientName) => {
    setExpandedClient(expandedClient === clientName ? null : clientName);
  };

  return (
    <div className="client-table-section">
      <h2>Client Revenue Overview</h2>
      <table className="client-table">
        <thead>
          <tr>
            <th>Client</th>
            <th>Projection</th>
            <th>Actual</th>
            <th>Achievement %</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {clients.map((client) => (
            <React.Fragment key={client.name}>
              <tr
                className={`client-row ${selectedClient === client.name ? 'selected' : ''}`}
                onClick={() => onSelectClient(client.name)}
              >
                <td className="client-name">{client.name}</td>
                <td>₹{(client.projection / 100000).toFixed(1)}L</td>
                <td>₹{(client.actual / 100000).toFixed(1)}L</td>
                <td>
                  {client.projection > 0
                    ? ((client.actual / client.projection) * 100).toFixed(1)
                    : 0}%
                </td>
                <td>
                  <button
                    className="expand-btn"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleExpand(client.name);
                    }}
                  >
                    {expandedClient === client.name ? '−' : '+'}
                  </button>
                </td>
              </tr>
              {expandedClient === client.name && (
                <tr className="expanded-row">
                  <td colSpan="5">
                    <div className="service-breakdown">
                      <h4>Service Breakdown (Latest Month)</h4>
                      <div className="services-grid">
                        {months.length > 0 && Object.entries(
                          client.monthlyData[months[months.length - 1]] || {}
                        ).map(([service, value]) => (
                          <div key={service} className="service-item">
                            <div className="service-name">{service}</div>
                            <div className="service-value">₹{(value / 10000).toFixed(1)}L</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ClientTable;
