import React, { useState, useEffect } from 'react';
import { fetchRevenueData, calculateTotals } from '../api/googleSheets';
import Overview from './Overview';
import ClientTable from './ClientTable';
import TrendChart from './TrendChart';
import CSatForm from './CSatForm';
import ResourceView from './ResourceView';
import '../styles/Dashboard.css';

const Dashboard = () => {
  const [clients, setClients] = useState([]);
  const [revenueData, setRevenueData] = useState(null);
  const [totals, setTotals] = useState(null);
  const [months, setMonths] = useState([]);
  const [selectedClient, setSelectedClient] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const data = await fetchRevenueData();
        setRevenueData(data);
        setClients(data.clients.map((c) => c.name));
        setMonths(data.months);
        const totalsData = calculateTotals(data.clients);
        setTotals(totalsData);
        if (data.clients.length > 0) {
          setSelectedClient(data.clients[0].name);
        }
        setError(null);
      } catch (err) {
        setError('Failed to load revenue data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadData();

    // Refresh data every 5 minutes
    const interval = setInterval(loadData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="dashboard-container">
        <div className="loading">Loading dashboard...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-container">
        <div className="error">{error}</div>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <h1>SAM Dashboard - Bangalore Revenue Tracking</h1>
        <p>Real-time client revenue, delivery, and performance metrics</p>
      </header>

      {totals && <Overview totals={totals} lastUpdate={new Date()} />}

      <div className="dashboard-nav">
        <button
          className={`nav-btn ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          Overview
        </button>
        <button
          className={`nav-btn ${activeTab === 'clients' ? 'active' : ''}`}
          onClick={() => setActiveTab('clients')}
        >
          Clients
        </button>
        <button
          className={`nav-btn ${activeTab === 'trends' ? 'active' : ''}`}
          onClick={() => setActiveTab('trends')}
        >
          Trends
        </button>
        <button
          className={`nav-btn ${activeTab === 'csat' ? 'active' : ''}`}
          onClick={() => setActiveTab('csat')}
        >
          CSat Scores
        </button>
        <button
          className={`nav-btn ${activeTab === 'resources' ? 'active' : ''}`}
          onClick={() => setActiveTab('resources')}
        >
          Resources
        </button>
      </div>

      <div className="dashboard-content">
        {activeTab === 'overview' && revenueData && (
          <ClientTable
            clients={revenueData.clients}
            months={months}
            onSelectClient={setSelectedClient}
            selectedClient={selectedClient}
          />
        )}

        {activeTab === 'clients' && revenueData && (
          <ClientTable
            clients={revenueData.clients}
            months={months}
            onSelectClient={setSelectedClient}
            selectedClient={selectedClient}
          />
        )}

        {activeTab === 'trends' && revenueData && (
          <TrendChart clients={revenueData.clients} months={months} />
        )}

        {activeTab === 'csat' && (
          <CSatForm clients={clients} months={months} />
        )}

        {activeTab === 'resources' && (
          <ResourceView clients={clients} />
        )}
      </div>

      <footer className="dashboard-footer">
        <p>Last updated: {new Date().toLocaleString('en-IN')}</p>
        <p>Data sources: Google Sheets (via Windsor.ai)</p>
      </footer>
    </div>
  );
};

export default Dashboard;
