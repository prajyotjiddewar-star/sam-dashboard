const axios = require('axios');

// Parse raw sheet data into structured format
const parseSheetData = (values) => {
  if (!values || values.length < 3) return { clients: [], months: [] };

  const headerRow = values[2];
  const servicesByMonth = {};

  let currentMonth = null;
  for (let i = 4; i < headerRow.length; i++) {
    const cell = headerRow[i];
    if (cell && cell.includes('2026')) {
      currentMonth = cell.trim();
      servicesByMonth[currentMonth] = [];
    }
  }

  const serviceRow = values[3];
  currentMonth = null;
  for (let i = 4; i < serviceRow.length; i++) {
    const cell = serviceRow[i];
    if (headerRow[i] && headerRow[i].includes('2026')) {
      currentMonth = headerRow[i].trim();
    }
    if (currentMonth && cell && cell !== 'Total') {
      if (!servicesByMonth[currentMonth].includes(cell)) {
        servicesByMonth[currentMonth].push(cell);
      }
    }
  }

  const clients = [];
  for (let i = 5; i < values.length; i++) {
    const row = values[i];
    if (!row || !row[0]) break;

    const clientName = row[0];
    const clientData = {
      name: clientName,
      projection: parseFloat(row[1]) || 0,
      actual: parseFloat(row[2]) || 0,
      achieved: parseFloat(row[3]) || 0,
      monthlyData: {},
    };

    let colIndex = 4;
    for (let m = 0; m < Object.keys(servicesByMonth).length; m++) {
      const month = Object.keys(servicesByMonth)[m];
      const monthServices = servicesByMonth[month];
      clientData.monthlyData[month] = {};

      for (let s = 0; s < monthServices.length; s++) {
        const service = monthServices[s];
        const value = parseFloat(row[colIndex]) || 0;
        clientData.monthlyData[month][service] = value;
        colIndex++;
      }
      colIndex++;
    }

    if (clientName && clientName !== 'Total') {
      clients.push(clientData);
    }
  }

  return { clients, months: Object.keys(servicesByMonth) };
};

exports.handler = async (event) => {
  try {
    const WINDSOR_API_KEY = process.env.WINDSOR_API_KEY;
    const SHEET_ID = process.env.REACT_APP_GOOGLE_SHEET_ID;

    if (!WINDSOR_API_KEY) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'WINDSOR_API_KEY not configured in environment' }),
      };
    }

    if (!SHEET_ID) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'REACT_APP_GOOGLE_SHEET_ID not configured in environment' }),
      };
    }

    console.log('Fetching data from Windsor for sheet:', SHEET_ID);

    // Call Windsor.ai API to fetch Google Sheets data
    const response = await axios.get('https://api.windsor.ai/v1/data', {
      params: {
        connector: 'googlesheets',
        resource: SHEET_ID,
      },
      headers: {
        Authorization: `Bearer ${WINDSOR_API_KEY}`,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    });

    console.log('Data received from Windsor, parsing...');

    const values = response.data.values || response.data;
    const parsedData = parseSheetData(values);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify(parsedData),
    };
  } catch (error) {
    console.error('Windsor fetch error:', error.message);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        error: error.message,
        details: error.response?.data || 'No additional details available',
      }),
    };
  }
};
